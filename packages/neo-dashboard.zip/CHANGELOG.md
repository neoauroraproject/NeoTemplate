# Changelog

All notable changes to the NeoTemplate SDK will be documented in this file.

## [1.2.1] - 2026-10-12
### Fixed
- Move Add to App into the Quick Actions modal so the main page stays clean.
- Fix app-row typography so name and description no longer collide.

## [1.0.0] - 2026-06-26
### Added
- Initial release of the NeoTemplate SDK.
- Core folder structure established.
- `manifest.json` schema defined.
- Base `index.html` and `sub.html` templates created.
- CSS Variables API established in `main.css`.
- Modular Vanilla JS helpers added in `app.js`.
