/**
 * NeoTemplate Preview Engine
 * Dynamically loads the parent index.html, injects mock data, and replaces the DOM.
 */

async function initPreview() {
    try {
        const loader = document.getElementById('preview-loader');
        loader.innerText = 'Loading Mock Data...';
        
        const mockResponse = await fetch('mock-data.json');
        if (!mockResponse.ok) throw new Error('Failed to load mock-data.json');
        const mockData = await mockResponse.json();

        loader.innerText = 'Loading Production Template...';
        const htmlResponse = await fetch('../index.html');
        if (!htmlResponse.ok) throw new Error('Failed to load ../index.html');
        let htmlContent = await htmlResponse.text();

        loader.innerText = 'Injecting Variables...';
        
        // Very basic Go template parser mimicking `{{ .variable }}` and basic `{{ if .var }}...{{ else }}...{{ end }}`
        
        // 1. Handle basic {{ if eq .obj.Total 0 }}Unlimited{{ else }}{{ .obj.Total }}{{ end }}
        htmlContent = htmlContent.replace(/\{\{\s*if\s+eq\s+([a-zA-Z0-9._]+)\s+([0-9]+)\s*\}\}(.*?)\{\{\s*else\s*\}\}(.*?)\{\{\s*end\s*\}\}/gs, (match, variable, value, trueBlock, falseBlock) => {
            const actualVal = mockData[variable];
            return String(actualVal) === value ? trueBlock : falseBlock;
        });

        // 2. Handle basic boolean {{ if .obj.Enable }}Active{{ else }}Inactive{{ end }}
        htmlContent = htmlContent.replace(/\{\{\s*if\s+([a-zA-Z0-9._]+)\s*\}\}(.*?)\{\{\s*else\s*\}\}(.*?)\{\{\s*end\s*\}\}/gs, (match, variable, trueBlock, falseBlock) => {
            const actualVal = mockData[variable];
            return actualVal ? trueBlock : falseBlock;
        });

        // 3. Replace simple variables {{ .variable }}
        for (const [key, value] of Object.entries(mockData)) {
            const regex = new RegExp(`\\{\\{\\s*${key.replace(/\./g, '\\.')}\\s*\\}\\}`, 'g');
            htmlContent = htmlContent.replace(regex, value);
        }

        // 4. Fix relative asset paths from preview/ to ../
        // e.g. src="assets/..." -> src="../assets/..."
        htmlContent = htmlContent.replace(/(src|href)="assets\//g, '$1="../assets/');

        // Inject into DOM
        document.open();
        document.write(htmlContent);
        document.close();

    } catch (err) {
        document.getElementById('preview-loader').innerText = 'Preview Engine Error: ' + err.message;
        console.error(err);
    }
}

initPreview();
