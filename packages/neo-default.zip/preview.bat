@echo off
cd /d "%~dp0"
echo Starting NeoTemplate Preview Engine...
echo This will open a local development server on a dynamic port to bypass browser CORS restrictions.
echo.
node preview/server.js
